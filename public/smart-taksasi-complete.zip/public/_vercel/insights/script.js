// Vercel Insights fallback mock
(function() {
  window.va = window.va || function () { (window.vaq = window.vaq || []).push(arguments); };
})();
